import json
from collections import defaultdict

from jira import JIRA
import pandas as pd
import requests
from requests.packages.urllib3.exceptions import InsecureRequestWarning
import multiprocessing as mp
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

#import config as cfg
from datetime import datetime
date = datetime.now().strftime("%Y_%m_%d_%I_%M_%S_%p")

#File to save execution summary data - CHANGE every run
file_name="./ExecutionSummary/ExecutionSummarySheet1888_Parallel_03252022.csv"

authDetails=("lakshmypriya-kuttappan.chettiar-ananda-lekshmy@allianz.com", "Kripakalk4#")
#authDetails={cfg.JMP["userName"],cfg.JMP["password"]}
header = {'Content-Type': 'application/json'}

url="https://jmp.allianz.net/rest/tests/1.0/reports/testresults?epicJQL=&jql=&maxResults=30000&page=1&projectId=19120&startAt=00&tql=testResult.projectId+IN+(19120)+AND+testResult.executionDate+%3E%3D+%272022-02-01%27+AND+testResult.executionDate+%3C%3D+%272022-03-01%27+AND+testCase.onlyLastTestResult+IS+false"

def exec_details(record):

    tcKey = record['testCase']['key']
    print("tckey",tcKey)
    # url ="https://jmp.allianz.net/rest/tests/1.0/testcase/AZA-T112294
    url = "https://jmp.allianz.net/rest/tests/1.0/testcase/" + tcKey
    tc = requests.get(url, verify=False, headers=header, auth=authDetails)
    # tcData = html.text
    tcData = json.loads(tc.text)
    tcPriority = tcData['priority']['name']
    tcID = tcData['id']
    OEName = ""
    tcType = ""
    releaseID = ""
    cycleKey = ""
    cycleName = ""
    tcModule = ""
    tcAssignedTeam=""
    try:
        customData = tcData['customFieldValues']

        # Type of Test Case field Value
        nameType = "Test Case Type"

        # Requested By OE Custom Field Value
        nameOE = "In scope OEs"

        # Module name
        moduleName = "Module"

        # Assigned Team

        assignedTeam="Assigned Team"

        for i in customData:
            fieldName = i['customField']['name']

            if fieldName == nameOE:
                try:
                    id = i['stringValue']
                    data2 = i['customField']['options']
                    for j in data2:
                        optionId = j['id']
                        if str(optionId) == str(id):
                            OEName = j['name']
                except KeyError:
                    print("Keyerror for intValue - no testcase type", tcKey)
                    # Handling for this where there was no In scope OEs selected

            if fieldName == nameType:

                try:
                    id = i['intValue']
                    data2 = i['customField']['options']
                    for j in data2:
                        optionId = j['id']
                        if str(optionId) == str(id):
                            tcType = j['name']
                except KeyError:

                    try:
                        id = i['stringValue']
                        id = id[1:-1]
                        data2 = i['customField']['options']
                        for j in data2:
                            optionId = j['id']
                            if str(optionId) == str(id):
                                tcType = j['name']
                    except KeyError:
                        print("Keyerror for intValue - no testcase type", tcKey)
                        # " handling for this where there was no proper Test Case Type node
            # test case module

            if fieldName == moduleName:

                try:
                    id = i['stringValue']
                    data2 = i['customField']['options']
                    for j in data2:
                        optionId = j['id']
                        if str(optionId) == str(id):
                            tcModule = j['name']
                except KeyError:
                    print("Keyerror for intValue - no module name", tcKey)

            # test case assigned team field
            if fieldName == assignedTeam:

                try:
                    id = i['intValue']
                    data2 = i['customField']['options']
                    for j in data2:
                        optionId = j['id']
                        if str(optionId) == str(id):
                            tcAssignedTeam = j['name']
                except KeyError:
                    print("Keyerror for intValue - no assigned team name", tcKey)
                    # " handling for this where there was no proper Test Case Type node

        try:
            # print("inside....")
            cycleKey = record['testRun']['key']
            # print(cycleKey)
            # cycleName=record['testRun']['name']
            url = "https://jmp.allianz.net/rest/tests/1.0/testrun/" + str(cycleKey) + "?fields=projectVersionId"
            cycle = requests.get(url, verify=False, headers=header, auth=authDetails)
            cycleData = json.loads(cycle.text)
            if len(cycleData) != 0:
                releaseVersion = cycleData['projectVersionId']
                try:
                    url = "https://jmp.allianz.net/rest/api/2/version/" + str(releaseVersion)
                    release = requests.get(url, verify=False, headers=header, auth=authDetails)
                    releaseData = json.loads(release.text)
                    releaseID = releaseData['name']
                except Exception as e:
                    print("exception occurred in getting release version, proceeding to next ", tcKey)
        except Exception as e:
            print("exception occurred in getting cycle details, proceeding to next ", tcKey)
    except KeyError:
        print("keyerror ", tcKey)
        # fetching release version details from cycles API

    d = {
        'Test Case.Key': record['testCase']['key'],
        'Execution.Key': record['key'],
        'Execution.Result': record['status']['name'],
        'Cycle.Key': cycleKey,
        # 'Cycle Name': cycleName,
        'Test Case.Name': record['testCase']['name'],
        'Test Case.Priority': tcPriority,
        'Test Cycle.Version': releaseID,
        'Test Case.In scope OEs': OEName,
        'Test Case.Test Case Type': tcType,
        'Testcase.AssignedTeam':tcAssignedTeam,
        'Test Case.Module': tcModule,
        'ExecutionDate': record['executionDate']
    }
    dataset = pd.DataFrame(d, index=[0])
    #df = dataset.append(d, ignore_index=True)
    with open(file_name, 'a') as f:
        dataset.to_csv(f, header=f.tell() == 0)



#if __name__ == '__main__':
def Execution_Summary():
    try:
        html = requests.get(url, verify=False, headers=header, auth=authDetails)
        data = html.text
        jsonLink = json.loads(data)
        results = jsonLink['results']

        count = 0
        pool = mp.Pool(mp.cpu_count())
        print(mp.cpu_count())

        data_outputs = pool.map(exec_details, [result for result in results])

    finally:
        pool.close()
        pool.join()


