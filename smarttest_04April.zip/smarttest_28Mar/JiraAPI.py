import json
from collections import defaultdict

from jira import JIRA
import pandas as pd
import requests
from requests.packages.urllib3.exceptions import InsecureRequestWarning
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
jira = None
issues = []

def login_jira_api(user, pas):
    jira = JIRA(options = {'server': 'https://jmp.allianz.net/','verify': False}, basic_auth =(user, pas))
#issue = jira.issue('AZA-104850')
#summary = issue.fields.summary
#print(summary)
    return jira


#issues =jira.search_issues('project=\"ABS Sahara \" and type="Story" and key="AZA-106658"',maxResults=3)
#issues =jira.search_issues('project=\"ABS Sahara \" and type="Story" and fixVersion in ("Release 18", "Release 17","Release 16", "Release 15") and status not in ("Descoped")',maxResults=950)
def jira_bugs(jira):

    global issues
    issues =jira.search_issues('project=\"ABS Sahara \" and type="Story" and fixVersion in ("Release 15") and status not in ("Descoped")',maxResults=950)

    df = pd.json_normalize(issues)
    print(df)

def demo():
    global issues
    issuesDF = pd.DataFrame()
    p=0
    for issue in issues:
        print(issue.key)
        p=p+1
        print("count: ",p)
        issueID=issue.id
        url="https://jmp.allianz.net/rest/tests/1.0/issue/"+str(issueID)+"/tracelinks"
        header = {'Content-Type': 'application/json'}
        html = requests.get(url, verify=False, headers=header, auth=("lakshmypriya-kuttappan.chettiar-ananda-lekshmy@allianz.com", "Kripakalk4#"))
        data = html.text
        linkedTCs = []
        import json
        j=json.loads(data)
        j=j['testCase']['coverage']['traceLinks']

        for x in j:
            t=x['testCase']['key']
            linkedTCs.append(t)
        LinkedIssues=[]
        if (issue.fields.issuelinks):
                for issueLinked in issue.fields.issuelinks:
                    if hasattr(issueLinked, "outwardIssue"):
                        outwardIssue = issueLinked.outwardIssue
                        LinkedIssues.append(outwardIssue.key)
                        #print("\tOutward: " + outwardIssue.key)
                        if str(jira.issue(outwardIssue.key).fields.issuetype.name) == 'Bug':
                            if str(jira.issue(outwardIssue.key).fields.status) != 'Descoped':
                               LinkedIssues.append(outwardIssue.key)
                    if hasattr(issueLinked, "inwardIssue"):
                        inwardIssue = issueLinked.inwardIssue
                        try:
                            if str(jira.issue(inwardIssue.key).fields.issuetype.name) == 'Bug':
                                try:
                                    if str(jira.issue(inwardIssue.key).fields.status) != 'Descoped':
                                        LinkedIssues.append(inwardIssue.key)
                                except KeyError:
                                    print("keyerror ", issue.key)

                        except KeyError:
                            print("keyerror ", issue.key)
                            # fetching release version details from cycles API

        d = {
            'key': issue.key,
            'id':issue.id,
            'components': issue.fields.components,
             'summary': issue.fields.summary,
            'fixVersions': issue.fields.fixVersions,
            'issuetype': issue.fields.issuetype.name,
            'priority': issue.fields.priority.name,
            'resolution': issue.fields.resolution,
            'status.name': issue.fields.status.name,
            'Linked.issues': LinkedIssues,
            'linked.testcases':linkedTCs,
        }
        issuesDF = issuesDF.append(d, ignore_index=True)
        #print(issuesDF.head().to_string())

    print(issuesDF.count())

    issuesDF.to_csv('./UserStory/USData_Release15.csv')


def US_summary(user, pas):
    print("Generating US Summary")
    jra = login_jira_api(user, pas)
    jira_bugs(jra)
    demo()

