import json
from collections import defaultdict

from jira import JIRA
import pandas as pd
import requests
from requests.packages.urllib3.exceptions import InsecureRequestWarning


def CreateBugReport():
    requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

    jira = JIRA(options={'server': 'https://jmp.allianz.net/', 'verify': False},
                basic_auth=("lakshmypriya-kuttappan.chettiar-ananda-lekshmy@allianz.com", "Kripakalk4#"))
    issue = jira.issue('AZA-104850')
    summary = issue.fields.summary
    print(summary)

    # 114900, AZA-110688"'
    # issues =jira.search_issues('project=\"ABS Sahara \" and type="Bug" and key="AZA-114006"',maxResults=3)
    # issues =jira.search_issues('project=\"ABS Sahara \" and type="Bug" and fixVersion in ("Release 19", "Release 18","Release 17", "Release 16") and status not in ("Descoped") and resolution not in ("Descoped")',maxResults=1000)
    issues = jira.search_issues(
        'project=\"ABS Sahara \" and type="Bug" and fixVersion in ("Release 15") and status not in ("Descoped") and resolution not in ("Descoped")',
        maxResults=1000)
    df = pd.json_normalize(issues)
    issuesDF = pd.DataFrame()
    p = 0
    for issue in issues:
        print(issue.key)
        p = p + 1
        print("count: ", p)
        issueID = issue.id
        # print(issueID)
        url = "https://jmp.allianz.net/rest/tests/1.0/issue/" + str(issueID) + "/tracelinks"
        header = {'Content-Type': 'application/json'}
        html = requests.get(url, verify=False, headers=header,
                            auth=("lakshmypriya-kuttappan.chettiar-ananda-lekshmy@allianz.com", "Kripakalk4#"))
        data = html.text
        linkedTCs = []
        linkedCycles = []
        linkedcoverage = []
        import json
        jsonLink = json.loads(data)
        j = jsonLink['testResult']['blocks']['traceLinks']
        k = jsonLink['testCase']['coverage']['traceLinks']

        for x in j:
            t = x['testResult']['testCase']['key']
            linkedTCs.append(t)
            try:
                c = x['testResult']['testRun']['key']
                linkedCycles.append(c)
            except KeyError:
                print("Keyerror for ", issue.key)
                # "AZA-110688" handling for this where there was no cycles/Testrun node

        for x in k:
            coverage = x['testCase']['key']
            # print("coverage:", coverage)
            n = 0
            for i in linkedTCs:
                if i == coverage:
                    n = n + 1
                    break
            if n == 0:
                linkedTCs.append(coverage)
        d = {
            'key': issue.key,
            'id': issue.id,
            'summary': issue.fields.summary,
            'fixVersions': issue.fields.fixVersions,
            'issuetype': issue.fields.issuetype.name,
            'priority': issue.fields.priority.name,
            'resolution': issue.fields.resolution,
            'status.name': issue.fields.status.name,
            'linked.testcases': linkedTCs,
            'Linked.Cycles': linkedCycles
        }
        issuesDF = issuesDF.append(d, ignore_index=True)
        # print(issuesDF.head().to_string())

    print(issuesDF.count())

    issuesDF.to_csv('./Bugs/BugData_Release15.csv')
