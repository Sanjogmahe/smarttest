from ast import literal_eval
import pandas as pd
import os
import glob
import numpy as np
from datetime import datetime
import os

def GenerateInputFiles():
    date = datetime.now().strftime("%Y_%m_%d_%I_%M_%S_%p")
    date1 = str(datetime.now().strftime("%Y%m%d"))
    #creating output folder as per the today's date

#    output_folder = '../InputSheet/OutputData_InputSheet/'+'InputDataFiles_'+date1
#    if not os.path.exists(output_folder):
#        os.makedirs(output_folder)

    output_folder = "./Input"

    # extract all test execution data
    AllTest_data = []

    for file in glob.glob("./ExecutionSummary/*.csv"):
        AllTest_data.append(pd.read_csv(file, encoding='latin-1', error_bad_lines=False))

    #for file in glob.glob("./ExecutionSummary/*.xlsx"):
     #   AllTest_data.append(pd.read_excel(file))
    testCaseData = pd.concat(AllTest_data, ignore_index=True)

    req_columns = ['Test Cycle.Version', 'Test Case.Key', 'Test Case.Name', 'Test Case.Priority', 'Test Case.In scope OEs',
                   'Test Case.Test Case Type', 'Test Case.Module', 'Testcase.AssignedTeam','Cycle.Key']
    testCaseData = testCaseData.drop(columns=[col for col in testCaseData if col not in req_columns], axis=1)

    #considering only required releases - Release 15 to Release 19 and removing duplicates
    testCaseData=testCaseData.loc[testCaseData['Test Cycle.Version'].isin(['Release 15', 'Release 16', 'Release 17','Release 18','Release 19'])]
    print(testCaseData.head(150))
    print(testCaseData.count())
    #testCaseData.drop_duplicates(keep='last',subset=['Test Case.Key','Test Cycle.Version','Test Case.Name','Test Case.Priority','Test Case.In scope OEs','Cycle.Key','Test Case.Test Case Type'], inplace=True)
    testCaseData = testCaseData.drop_duplicates(keep='last', inplace=False)
    print(testCaseData.count())

    #setting Target for previous releases based on whether it was a regression test case
    testCaseData['Target'] = 0
    testCaseData.loc[testCaseData['Test Case.Test Case Type'].isin(['Regression', 'Smoke Test', 'Regression (Sys)']), 'Target'] = '1'
    #testCaseData=testCaseData.loc[~testCaseData['Test Case.Test Case Type'].isin(['UAT - P9'])]
    testCaseData=testCaseData[testCaseData["Test Case.Test Case Type"].str.contains("UAT - P9")==False]
    print(testCaseData.count())

    ## extracting user story data
    AllUS_data = []
    for file in glob.glob("./UserStory/*.csv"):
     AllUS_data.append(pd.read_csv(file))

    userStoryData = pd.concat(AllUS_data, ignore_index=True)
    userStoryData = userStoryData[~userStoryData['linked.testcases'].isin(['[]'])]

    userStoryData = userStoryData.fillna("NA")
    req_columns = ['key', 'fixVersions', 'priority', 'Linked.issues', 'linked.testcases']
    userStoryData = userStoryData.drop(columns=[col for col in userStoryData if col not in req_columns], axis=1)

    userStoryData['fixVersions'] = userStoryData['fixVersions'].map(lambda x: str(x)[22:])
    userStoryData['fixVersions'] = userStoryData['fixVersions'].str.split("'").str[0]
    userStoryData = userStoryData.loc[userStoryData['fixVersions'].isin(['Release 15', 'Release 16', 'Release 17', 'Release 18','Release 19'])]
    # extracting records which has Linked Issues and Linked testcases for those issues
    userStoryData = userStoryData[~userStoryData['Linked.issues'].isin(['[]'])]
    userStoryData = userStoryData[~userStoryData['linked.testcases'].isin(['[]'])]

    userStoryData = userStoryData.reset_index()
    linkedTCsInUS=userStoryData
    req_columns1 = ['fixVersions', 'linked.testcases']
    linkedTCsInUS= linkedTCsInUS.drop(columns = [col for col in linkedTCsInUS if col not in req_columns1], axis=1)
    #extracting all test cases which are linked to userstory and has defects associated to that userstory
    linkedTCsInUS['linked.testcases']=linkedTCsInUS['linked.testcases'].apply(literal_eval)
    linkedTCsInUS=linkedTCsInUS.explode('linked.testcases')

    #Bugs data extract
    AllBugs_data = []
    for file in glob.glob("./Bugs/*.csv"):
        AllBugs_data.append(pd.read_csv(file))

    #for file in glob.glob("./Bugs/*.xlsx"):
        #AllBugs_data.append(pd.read_excel(file))

    bugsData = pd.concat(AllBugs_data, ignore_index=True)

    #bugsData = pd.read_csv('BugbugsData.csv')
    bugsData=bugsData.fillna("NA")

    req_columns=['key','fixVersions','priority', 'linked.testcases']
    bugsData= bugsData.drop(columns = [col for col in bugsData if col not in req_columns], axis=1)
    bugsData['fixVersions'] = bugsData['fixVersions'].map(lambda x: str(x)[22:])
    bugsData['fixVersions'] = bugsData['fixVersions'].str.split("'").str[0]
    bugsData=bugsData[~bugsData['linked.testcases'].isin(['[]'])]
    bugsData = bugsData.loc[bugsData['fixVersions'].isin(['Release 15', 'Release 16', 'Release 17', 'Release 18','Release 19'])]
    bugsData.head(10)

    #extracting records from Bugs export which has linked test cases
    bugsData = bugsData.reset_index()
    linkedTCsInBugs=bugsData
    req_columns1 = ['fixVersions', 'linked.testcases']

    linkedTCsInBugs= linkedTCsInBugs.drop(columns = [col for col in linkedTCsInBugs if col not in req_columns1], axis=1)

    linkedTCsInBugs['linked.testcases']=linkedTCsInBugs['linked.testcases'].apply(literal_eval)
    linkedTCsInBugs=linkedTCsInBugs.explode('linked.testcases')

    #combining all test cases which have defects linkages from userstory and bugs data
    totalLinkedTCs=pd.concat([linkedTCsInBugs, linkedTCsInUS], axis=0, join='outer')
    totalLinkedTCs = totalLinkedTCs.reset_index(drop=True)

    totalLinkedTCs=totalLinkedTCs.drop_duplicates()
    #print(totalLinkedTCs.count())

    #additing new column for Any defects and making it was Yes if there is similar test key in defect linkages dataframe based on each release
    testCaseData['Any Defects'] = 'No'
    testCaseData = testCaseData.reset_index(drop=True)
    #print(testCaseData.head())

    totalLinkedTCs=totalLinkedTCs.rename(columns={"linked.testcases":"Test Case.Key"})
    #print(totalLinkedTCs.head(5))
    releases = ['Release 15', 'Release 16', 'Release 17','Release 18','Release 19' ]
    finalTotalData=pd.DataFrame()
    for release in releases:
     testCaseData_subset=testCaseData.loc[testCaseData['Test Cycle.Version']==release]
     totalLinkedTCs_subset=totalLinkedTCs.loc[totalLinkedTCs['fixVersions']==release]
     TestKeys = totalLinkedTCs_subset['Test Case.Key'].to_list()

     for TestCaseKey in testCaseData_subset['Test Case.Key']:
      exists = TestCaseKey in TestKeys
      if TestCaseKey in TestKeys:
       testCaseData_subset.loc[testCaseData_subset['Test Case.Key'] == TestCaseKey, 'Any Defects'] = 'Yes'

     finalTotalData = finalTotalData.append(testCaseData_subset, ignore_index=True)

    #remaning and sorting columns to align with ML code input
    finalTotalData = finalTotalData.reset_index(drop=True)
    finalTotalData=finalTotalData.rename(columns={"Test Case.Key":"ID", "Test Case.Name":"Test Case Title", "Test Case.Priority":"TestCase Priority", "Test Cycle.Version":"Release ID", "Testcase.AssignedTeam":"Module","Test Case.In scope OEs":"In scope OEs","Any Defects":"Any Defects"})
    finalTotalData=finalTotalData.drop(columns=['Test Case.Test Case Type','Cycle.Key'])
    finalTotalData = finalTotalData[['ID','Release ID','Test Case Title','TestCase Priority','Any Defects','Module','Target','In scope OEs']]

    print(finalTotalData.head(5).to_string())

    #master input sheet with train and test data
    file_name=output_folder+"/Master_input_Sheet"
    finalTotalData.to_excel(file_name + date + '.xlsx',engine='xlsxwriter',index=False)
    finalTotalData.to_excel(file_name + '.xlsx', engine='xlsxwriter', index=False)

    # Training Data from Release 15 to Release 18
    TrainingData=finalTotalData
    TrainingData = TrainingData.loc[TrainingData['Release ID'].isin(['Release 15', 'Release 16', 'Release 17', 'Release 18'])]

    file_name_train= output_folder+"/Train_input_Sheet"
    TrainingData.to_excel(file_name_train + date + '.xlsx',engine='xlsxwriter', index=False)
    TrainingData.to_excel(file_name_train + '.xlsx', engine='xlsxwriter', index=False)

    # Prediction data based on Release 19
    PredictionData=finalTotalData
    PredictionData = PredictionData.loc[PredictionData['Release ID'].isin(['Release 19'])]
    PredictionData = PredictionData.loc[PredictionData['Target']==0]
    PredictionData=PredictionData.drop(columns=['Target'])

    file_name_pred= output_folder+"/Pred_input_Sheet"
    PredictionData.to_excel(file_name_pred + date + '.xlsx',engine='xlsxwriter',index=False)
    PredictionData.to_excel(file_name_pred + '.xlsx', engine='xlsxwriter', index=False)

    print("Input File for Prediction Created")

