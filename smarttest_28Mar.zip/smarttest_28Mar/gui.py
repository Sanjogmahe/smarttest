from flask import Flask, redirect, url_for, render_template, request, Response
import pandas as pd
import time
import os
from JiraAPI import login_jira_api, jira_bugs, US_summary
from JMP_GenericData import project_list, project_releases
from JiraBugsAPI import CreateBugReport
from JIRAExecutionParallel import Execution_Summary
#
# from main_smart_test import PredictionModel
import main_smart_test
import TrainInputFile

app = Flask(__name__)


@app.route('/')
def welcome():
    return render_template('index1.html')


username = ''
password = ''


@app.route('/login_popup', methods=['GET', 'POST'])
def login_popup():
    if request.form.get('submit') == 'Establish Connection':
        global username
        global password

        username = request.form.get('email')
        password = request.form.get('password')
        # login = login_jira_api(username,password)
        # jira_bugs(login)
        projects = project_list()
        project_rel = project_releases()
        return render_template('jira.html', projects=projects.projectName, project_id=projects.projectID,
                               project_rel=project_rel.releaseName)
    if request.form.get('submit') == 'Extract User Story Data':
        US_summary(username, password)
    if request.form.get('submit') == 'Extract Defects Data':
        CreateBugReport()
    if request.form.get('submit') == 'Exctract Execution Summary Data':
        Execution_Summary()
    #    movies = pd.read_excel('movies.xls')
    #    headings = list(movies.columns.values.tolist())
    #    data = movies.to_numpy()

    #    return render_template('index.html', headings=headings, data=data)
    return render_template('jira.html')


# @app.route('/Extract_US', methods=['GET'])
# def Extract_US():
#     US_summary(username, password)
#     return render_template('jira.html')
#
#
# @app.route('/Extract_Defects', methods=['GET'])
# def Extract_Defects():
#     CreateBugReport()
#     return render_template('jira.html')
#
#
# @app.route('/Extract_ES', methods=['GET'])
# def Extract_ES():
#     Execution_Summary()
#     return render_template('jira.html')


@app.route('/Extract_button', methods=['GET'])
def Extract_button():
    time.sleep(5)
    return render_template('index1.html', Extract_Progress="Extraction of Data is Complete")


@app.route('/Create_button', methods=['GET'])
def Create_button():
    TrainInputFile.GenerateInputFiles()
    # main_smart_test.TrainModel()
    return render_template('index1.html', Create_Progress="Creation of Input Data Complete")


@app.route('/Execute_button')
def Execute_button():
    OpFile = main_smart_test.PredictionModel()
    op_file_path = os.path.abspath(OpFile)
    return render_template('index1.html', Execute_Progress="Processing Complete", Output_Status="Output Available",
                           Output_File_Path=op_file_path)


@app.route('/Output_button', methods=['GET'])
def Output_button():
    outputFile = main_smart_test.getOuputFileName()
    if (outputFile == "Null"):
        return render_template('index1.html', Output_Status="No Output File Found. Run Test.")

    op_file = os.path.abspath(outputFile)
    os.startfile(op_file)
    return render_template('index1.html')


if __name__ == '__main__':
    app.run(debug=True)
