import time

import pandas as pd
from selenium.common.exceptions import NoSuchElementException, ElementClickInterceptedException
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from datetime import date
from selenium.webdriver.chrome.options import Options
from Extraction.Funtion import cli,ent,url,iframe,justCli,hover,clear,justEnt,soupContent,quit,waituntil,sendkey,wait,el_id,arg,key,xp1,triel
from selenium.webdriver.common.desired_capabilities import DesiredCapabilities
from selenium.webdriver.support import expected_conditions as EC


options = Options()
today = date.today()
d1 = today.strftime("%m/%d/%Y")


url("https://ily59392.live.dynatrace.com/#newservices/serviceOverview;id=SERVICE-6FD15EDAE6F19ACB;gtf=2020-09-21T19:00:00+05:30%20to%202020-09-22T03:00:00+05:30;gf=-3435563340085212296")

suffixID = 'SF-USLL00071318'
ent("//input[@id='email_verify']","extern.awhale_sneha1@allianz.com")
cli("//button[@id='next_button']")
justCli("//a[contains(text(),'Hosts')]")
cli("//span[@class='dVm-j']")
cli("//span[contains(text(),'mz-az-agcs-smo')]")
cli("//div[@class='gwt-Label dht-db']")
triel("//input[@class='gwt-TextBox dht-bb dht-kb dht-mb']")
wait(20)
waituntil("//input[@class='gwt-TextBox dht-bb']")
ent("//input[@class='gwt-TextBox dht-bb']","2020-11-02 17:00 to 2020-11-02 20:10")
sendkey("//input[@class='gwt-TextBox dht-bb dht-mb dht-kb']")
arg("//span[contains(text(),'sla28565.srv.allianz')]")
justCli("//a[contains(text(),'JBoss domain jbeap-* (alz-eu-ace_test_sv_eap_perf-sit_pegaprpc_01)')]")
justCli("/*[name()='path' and @id='callerBox']")
justCli("//span[contains(text(),'View dynamic requests')]")
justCli("//span[contains(text(),'More...')]")
justCli("//span[contains(text(),'View exception analysis')]")



#clear("//div[@class='gwt-Label dht-db']")
# xp1()
# key()
# wait(10)
# xp()
# cli("//td[contains(text(),'JBoss domain jbeap-* (alz-eu-ace_test_sv_eap_perf-sit_pegaprpc_01)')]")


#wait.until(EC.invisibility_of_element_located((By.XPATH,
              #"//div[@class='blockUI blockOverlay']")))
#el_id("//span[text()='sla28565.srv.allianz']").click()
#cli("//span[text()='sla28565.srv.allianz']")

#cli("//span[contains('sla28565.srv.allianz')]")

#cli("//a[contains(text(),'Test100 Perform100')]")
hover("//span[contains(text(),'Switch Application')]")
cli("//span[contains(text(),'Liability (Liability Underwriters)')]")
cli("//span[contains(text(),'Create Submission')]")
iframe("//iframe[@id='PegaGadget0Ifr']")
clear("//input[@id='OperatingEntityReceivedSubmission']")
time.sleep(1)
try:
    justCli("//input[@id='OperatingEntityReceivedSubmission']")
except ElementClickInterceptedException:
    justCli("//input[@id='OperatingEntityReceivedSubmission']")
ent("//input[@id='OperatingEntityReceivedSubmission']","AGCS Germany")
ent("//input[@id='OperatingEntityReceivedSubmission']",Keys.TAB)
try:
    justCli("//input[@id='OperatingEntityReceivedSubmission']")
except ElementClickInterceptedException:
    justCli("//input[@id='OperatingEntityReceivedSubmission']")
justEnt("//input[@id='OperatingEntityReceivedSubmission']",Keys.BACKSPACE)
justEnt("//input[@id='OperatingEntityReceivedSubmission']","y")
justEnt("//input[@id='OperatingEntityReceivedSubmission']",Keys.DOWN)
justEnt("//input[@id='OperatingEntityReceivedSubmission']", Keys.DOWN)
justEnt("//input[@id='OperatingEntityReceivedSubmission']",Keys.RETURN)
ent("//input[@id='SubmissionReceivedDate']",d1)
ent("//input[@id='InceptionDate']",d1)
cli("//button[contains(@name,'PartyDetails_pyWorkPage.SubmissionPage.InsuredPartyPage_1')]")
cli("//button[contains(@name,'NamesSearch_NamesSearchCriteriaPage_62')]")

content = soupContent()

LegalName=[]
ListName=[]
NameCode=[]
Country=[]
Street=[]
City=[]
PostCode=[]
Usages=[]
IRPID=[]

for i in range(1,5):
    try:

        time.sleep(4)
        soups = soupContent()
        Data=soups.findAll('div', attrs={'class': 'oflowDivM'})
        for i in range(0, 90, 9):
            LegalName.append(Data[i].text)
            ListName.append(Data[i+1].text)
            NameCode.append(Data[i+2].text)
            Country.append(Data[i+3].text)
            Street.append(Data[i+4].text)
            City.append(Data[i+5].text)
            PostCode.append(Data[i+6].text)
            Usages.append(Data[i+7].text)
            IRPID.append(Data[i+8].text)

        if i%10==1:
            justCli("//a[contains(text(),'Next')]")
        else:
            justCli("//a[contains(text()," + str(i) + ")]")
    except NoSuchElementException:
        break


flag=0
if flag==0:
    df = pd.DataFrame({'LegalName':LegalName,'ListName':ListName,'NameCode':NameCode,'Country':Country,
    'Street':Street,'City':City,'PostCode':PostCode,'Usages':Usages,'IRPID':IRPID})
    df.to_excel('BrokerData.xlsx', index=False, encoding='utf-8')
else:
    print("no write access")

quit()
print("Test Case Passed!!")