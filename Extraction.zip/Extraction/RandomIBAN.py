import time

import pandas as pd
from selenium.common.exceptions import NoSuchElementException, ElementClickInterceptedException
from selenium.webdriver.common.keys import Keys
from datetime import date
from Extraction.Funtion import cli,ent,url,iframe,justCli,hover,clear,justEnt,soupContent,quit



today = date.today()
d1 = today.strftime("%m/%d/%Y")

url("http://randomiban.com/?country=Spain")
iban=[]
i=0
while i<40:
    cli("//button[@id='gen_button']")
    soups = soupContent()
    Data=soups.findAll('p', attrs={'class': 'ibandisplay'})
    for s in Data:
        print(s.text)
    iban.append(s.text)
    i+=1
flag=0
if flag==0:
    df = pd.DataFrame({'IbanNo':iban})
    df.to_excel('IBAN.xlsx', index=False, encoding='utf-8')
else:
    print("no write access")

quit()
print("Test Case Passed!!")