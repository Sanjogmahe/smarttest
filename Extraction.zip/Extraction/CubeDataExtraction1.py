import re
import sys
import time
from lxml import etree
import urllib3
from bs4 import BeautifulSoup
import pandas as pd
from selenium.common.exceptions import NoSuchElementException, ElementClickInterceptedException
from selenium.webdriver.common.keys import Keys
from datetime import date
from Funtion import url, iframe, justCli, hover, clear, justEnt, soupContent, quit, default_iframe, CancelAlert



today = date.today()
d1 = today.strftime("%m/%d/%Y")

# url("https://sla25227.srv.allianz:15002/prweb/avsJh54iwYk%5B*/!STANDARD")
#url("https://jenkins-adp-tools-absi.apps.crp.ec1.aws.aztec.cloud.allianz/job/absi-deployments/job/wsi/job/absi-dev/job/sita/job/deploy-delivery/")
#url("https://absi-jira.srv.allianz:8443/login.jsp")
url("https://pp-ford-stg1.ga.allianz.com/customer-journey.html")
# suffixID = 'SF-USLL00071318'
# ent("//input[@id='txtUserID']","cube.perform101.test@allianz.com")
# ent("//input[@id='txtPassword']","rules")
# cli("//button[@id='sub']//span[@class='loginButtonText'][contains(text(),'Log in')]")
# justCli("//a[contains(text(),'Test101 Perform101')]")
# #cli("//a[contains(text(),'Test100 Perform100')]")
# hover("//span[contains(text(),'Switch Application')]")
# cli("//span[contains(text(),'Liability (Liability Underwriters)')]")
# cli("//span[contains(text(),'Create Submission')]")
#time.sleep(5)
#content = soupContent()

#iframe("//iframe[@id='PegaGadget0Ifr']")
#time.sleep(5)
content = soupContent()



#//span[contains(text(),'Renewal Type')]
#//input[@id='RenewalTypenot-renewable']

# ids = None
# classes = None
# types = None
# names = None

# c=content(text='Renewal Type')
# for d in c:
#     print(d)


#print(content(text="Line of Business"))


def uniqueAtt(text,li='',inside='trdtdtrdfc4535',selectchoice='fdsd214e54ftt'):
    content = soupContent()
    print('------------------------Style name------------------------')
    if inside is not 'trdtdtrdfc4535':
        print('---------------------Inside hu mai-----------------------')
        regex_text_inside = inside
        regex_special_removal_inside = regex_text_inside.replace('(', '\(').replace(')', '\)')
        regex_inside = re.compile('.*' + regex_special_removal_inside + '.*')
        search = content.find_all(text=regex_inside)
        if not search:
            print('----------------Dekhte hai kuch hota hai to-------------------------')
            return element_action(text, inside=inside, li=li, inputvalue=selectchoice, elementnotpresent='yes')
    print(selectchoice)
    #print(content)
    # for sea in search:
    #     if not sea.find_all(style='display: none;'):
    #         sea.previous_element
    #     else:
    #         print(sea)
    #         break

    print('------------------------Style name------------------------')
    con = None
    ids = None
    classes = None
    types = None
    names = None
    texts = None
    list = []
    if li is 'button':
        list = ['iframe', 'button']
    else:
        list = ['input', 'select', 'iframe']
    flag = False
    flag_2 = False
    c = None
    i = None
    j = None
    optionValue = None
    counter = 0
    regex_text = text
    regex_special_removal = regex_text.replace('(', '\(').replace(')', '\)')
    regex = re.compile('.*' + regex_special_removal + '.*')
    # regex = re.compile('.*'+text+'.*')
    # regex = re.compile('\?<!\S'+text+'?!\S')
    # regex = re.compile('(?:\S+\s)?\S*text\S*(?:\s\S+)?')


    #regex = re.compile('\S*text\S*')


    if content(value=text):
        con = content(value=text)
        if content(text=text):
            con_text = content(text=text)
            print(text == 'Broker')
            print('Broker Content kya kar rha hai-------')
            print(con)
            for k in con_text:
                con.append(k)
    elif content(id=text):
        con = content(id=text)
    elif content(placeholder=text):
        con = content(placeholder=text)
    elif content(text=text):
        con = content(text=text)
    elif content(text=regex):
        con = content(text=regex)
        for elem in con:
            a = elem.parent
            print(a)
            #matching Partial Text with whitespaces
            s1 = text.split()
            print('s1')
            print(s1)  # ['TSN','qwe']
            D = elem.split()  # ['hug','(HSN/TSN)']
            print(D)
            flag_1 = False
            j = 0

            if len(s1) == len(D):  # 2 = 2 true
                for j in range(len(s1)):  # j=1, j= 2
                    flag_1 = False  # true
                    if s1[j] == D[j]:  # TSN=hug false # tst =tsn true
                        flag_1 = True
                    else:
                        break
            if flag_1 == True:
                print("It's a match")
                print(elem)
                print(con)
            if flag_1 == False:
                print("It's not a match")
                print(elem)
                con.remove(elem)
                print(con)


    print('---------------- Content ---------------------')
    if text == 'Broker':
        print(con)
        print('Printing all the labels')
        cont = content.find_all('label')
        for b in cont:
            print('-------------------------------------')
            print(b.text)

    print('Content of text or id or Placeholder :')
    # print(text)


    count_elem = 0

    for elem in con:

        # print("Inside main for lopp")
        # time.sleep(20)
        # print(elem)
        counter = 0
        a = elem.parent
        # print('Main element')
        # time.sleep(20)
        print(a)
        b = a  # b=<span
        print(len(con))
        print('------------------------tag name------------------------')
        print(b.name)
        count_elem = count_elem+1
        print('-------------Count--------------')
        print(len(con))
        print(count_elem)
        #if b.name is 'div':
        while True:

            counter = counter + 1
            print(counter)
            if counter == 15:
                print('no0000 element')
                print(selectchoice)
                print(len(con) == count_elem)
                if len(con) == count_elem:
                    return element_action(text, li=li, inputvalue=selectchoice, elementnotpresent='yes')
            if counter > 15:
                #counter = 0
                break

            for i in list:
                # print(i)
                c = None
                if (i is 'input'):
                    print('------------------------First If------------------------')
                    c = b.find(i, type != 'hidden')
                    print(c)
                else:

                    print('------------------------First else------------------------')
                    # print('------------------------Style name------------------------')
                    # search = b.find_all(i,style='display: none;')
                    # print(search)
                    # print('------------------------Style name------------------------')
                    if ('data-click' in str(b) and not 'data-click="...."' in str(b)) or 'button' in str(b) \
                            or 'submit' in str(b) or ('href' in str(b) and not 'href=""') or 'navigation' in str(b)\
                            or 'nx-radio' in str(b) or 'headers="a2"' in str(b):
                        # if b.find('input'):
                        #     c = b.find('input', type != 'hidden')
                        #     i = c.name
                        # else:
                        if b.find('button'):
                            print('---------------------- Button Found than just stop ----------------------')
                            c = b.find('button')
                            i = c.name
                        else:
                            print('------------------------Second If------------------------')
                            c = b
                            i = c.name
                    else:

                        print('------------------------second else------------------------')
                        c = b.find(i)
                # b = b.previous_element#Previous tag of <select>
                if (c is not None and c is not -1):

                    print('------------------------Third If------------------------')
                    #print('i Value Select see upar' + str(i))
                    if (i == 'select'):
                        print("-------------Inside Select IF----------")
                        print(c)  # <input tag
                        # u = c.find_all('option')
                        if selectchoice is not 'fdsd214e54ftt':
                            j = 'option'
                            u = content(j, text=selectchoice)[0]
                            print(u)
                            optionValue = u['value']
                            print(optionValue)
                            print('**')
                            s = 1
                            for r in u:
                                print(r)
                                # print('------------------Option '+ str(s) + ' ---> ' + str(r.text) +'--------------------')
                                s = s + 1

                    else:
                        print('-----only c----------')
                        print(c)
                    i = c.name
                    try:
                        ids = c['id']
                        print(ids)
                    except(KeyError):
                        ids = 'No Id'
                    try:
                        classes = c['class'][0]
                        print(classes)
                    except(KeyError):
                        classes = 'No Class'
                    try:
                        types = c['type']
                        print(types)
                    except(KeyError):
                        types = 'No Type'
                    try:
                        names = c['name']
                        print(names)
                    except(KeyError):
                        names = 'No Name'
                    try:
                        texts = c.text
                        print(text)
                    except(KeyError):
                        names = 'No Text'

                    #print('i Value C ke niche' + str(i))
                    flag = True
                    break
            b = b.previous_element

            if (flag == True):
                break
        if (flag == True):
            break

    mydict = {
        'id': ids,
        'class': classes,
        'type': types,
        'name': names,
        'text': texts
    }

    print('-----------------------------------Start-------------------')

    foundattrs = {}
    if (mydict['id'] is not None and mydict['class'] is not None and mydict['name'] is not None and mydict[
        'text'] is not None and mydict['type'] is not None):
        for x in mydict:

            if (mydict[x] is not 'No Class' and mydict[x] is not 'No Id' and mydict[x] is not 'No Name' and mydict[
                x] is not 'No Type' and mydict[x] is not 'No Text'):
                # print(x,mydict[x])
                foundattrs[x] = mydict[x]
                # foundattrs.append(x,mydict[x])

    else:
        print('no attrs found')
        return element_action(text, li=li, inputvalue=selectchoice, elementnotpresent='yes')


    print(foundattrs)
    print('-----------------------------------End-------------------')
    attname = None
    print(str(i) + " : i")
    # print("text value : " + str(foundattrs['text']))
    # print("class value : " + str(foundattrs['class']))
    # soup.findAll('entry', {'colname': 'col2'}))
    attributename = None
    for att in foundattrs:
        print(att)
        attributename = att
        print(foundattrs[att])
        t = []
        if (foundattrs[att] is not ''):
            if (str(att) == 'text'):

                t = content.find_all(i, text=foundattrs[att])
                if not t:
                    print('if wala text--------')
                    t = content.find_all(text=foundattrs[att])
                print("Text Tag-------------------")
                print(t)
                abc = len(t)-1
                u = 0
                for xyz in range(abc, -1, -1):
                    print(xyz)
                    print(abc)
                    print(str(t[xyz]))
                    if str(t[xyz]) in str(t[0]):
                        u = u+1
                        if u == abc+1:
                            wer = []
                            qwe=t[abc]
                            wer.append(qwe)
                            print("-------------------wer------------------")
                            print(wer)
                            t = wer
            else:
                t = content.find_all(i, {att: foundattrs[att]})
            print("T value -          --------")
            print(t)
        if (len(t) == 1):
            attname = att
            if attributename is 'text':

                # Absolute
                Tstr="<html><body>"+str(t[0].parent)+"</body></html>"
                root = etree.fromstring(Tstr)
                tree = etree.ElementTree(root)
                xpath_ab = '//' + '*' + '[contains(text()' + ',\'' + foundattrs[attname].strip() + '\')]'
                find_text = etree.XPath(xpath_ab)
                for target in find_text(root):

                    j=tree.getpath(target)
                    i = str(j).replace('/html/body/','')
                    print("______________absolute xpath_____________")
                    print(i)
            break
    xpathList = []
    #print('att name' + str(foundattrs[attname]))
    if attributename is 'text':
        xpath = '//' + i + '[contains(text()' + ',\'' + foundattrs[attname].strip() + '\')]'

    else:
        xpath = '//' + i + '[@' + attname + '=\'' + foundattrs[attname] + '\']'
    xpathList.append(xpath)
    if optionValue is not None:
        xpathoption = '//' + j + '[@' + 'value' + '=\'' + optionValue + '\']'
        xpathList.append(xpathoption)
    #print(xpath)
    return xpathList

def do_nothing():
    sys.exit()

def element_action(elementText, li='',inside='trdtdtrdfc4535', inputvalue='fdsd214e54ftt',elementnotpresent='No'):
    print('================element action==========================')
    print(inputvalue)
    print('Element Text : ------ '+elementText)
    #time.sleep(5)
    content = soupContent()
    #print(content)
    regex_special_removal = elementText.replace('(','\(').replace(')','\)')
    regex = re.compile('.*'+regex_special_removal+'.*')
    #print(content(text=regex))
    #print(content(placeholder=elementText))
    if (not content(text=regex) and not content(placeholder=elementText) and not content(value=elementText)) or elementnotpresent == 'yes':
        #print(content(text=regex))
    # if not content(text=elementText) or (variable = no elemet foind):
        print("Inside element if block")
        ig = content('iframe')
        if(not ig):
            raise Exception("Failed")
        print(ig)
        for k in ig:
            swit=k['id']
            pathi = uniqueAtt(swit)
            print(pathi)
            iframe(pathi[0])
            try:
                if inputvalue is not 'fdsd214e54ftt':
                    path = uniqueAtt(elementText)
                    if 'select' not in path[0]:
                        if inputvalue is not 'Hover':
                            print('Input value : ' + inputvalue)
                            print("xpath wala print : " + str(path[0]))
                            justCli(path[0])

                            clear(path[0])
                            time.sleep(1)
                            justEnt(path[0], inputvalue)
                            do_nothing()
                        else:
                            print('Hover value : ' + inputvalue)
                            print("xpath wala print : " + str(path[0]))
                            hover(path[0])
                            do_nothing()
                    else:
                        print('Select value inside else : ' + inputvalue)
                        path = uniqueAtt(elementText, inputvalue)
                        print("xpath wala print : " + str(path[0]))
                        justCli(path[0])
                        print('@@@@@@@@@@@@@@@@@@Option@@@@@@@@@@@@@@@@@@@@@@@')
                        print(path[1])
                        justCli(path[1])
                        do_nothing()
                else:
                    if(li == 'button'):
                        if(inside is 'trdtdtrdfc4535'):
                            path = uniqueAtt(elementText,li=li)
                            print("xpath wala print : " + str(path[0]))
                            # justCli(uniqueAtt(elementText))
                            justCli(path[0])
                            do_nothing()
                        else:
                            path = uniqueAtt(elementText, inside=inside, li=li)
                            print("xpath wala print : " + str(path[0]))
                            # justCli(uniqueAtt(elementText))
                            justCli(path[0])
                            do_nothing()
                    else:
                        path = uniqueAtt(elementText)
                        print("xpath wala print : " + str(path[0]))
                        # justCli(uniqueAtt(elementText))
                        justCli(path[0])
                        do_nothing()

                default_iframe()
                break
            except(SystemExit):
                print("It's Okay..!")
            except:
                print("Test Case Failed!!")
                print("Unexpected error:", sys.exc_info()[0])
                raise
            # except(TypeError):
            #     default_iframe()
            #     print('Could not find element iframe')


    else:
        print('----------------------else of element_action()----------------------------')
        try:
            if inputvalue is not 'fdsd214e54ftt':
                path = uniqueAtt(elementText, selectchoice=inputvalue)
                if 'select' not in path[0]:
                    if inputvalue is not 'Hover':
                        print('Input value : ' + inputvalue)
                        print("xpath wala print : " + str(path[0]))
                        justCli(path[0])

                        clear(path[0])
                        time.sleep(1)
                        justEnt(path[0], inputvalue)
                        do_nothing()
                    else:
                        print('Hover value : ' + inputvalue) #
                        print("xpath wala print : " + str(path[0]))
                        hover(path[0])
                        do_nothing()
                else:
                    print('Select value inside else : ' + inputvalue)
                    path = uniqueAtt(elementText, inputvalue)
                    print("xpath wala print : " + str(path[0]))
                    justCli(path[0])
                    print('@@@@@@@@@@@@@@@@@@Option@@@@@@@@@@@@@@@@@@@@@@@')
                    print(path[1])
                    justCli(path[1])
                    do_nothing()

            else:
                if (li == 'button'):
                    if (inside is 'trdtdtrdfc4535'):
                        path = uniqueAtt(elementText, li=li)
                        print("xpath wala print : " + str(path[0]))
                        # justCli(uniqueAtt(elementText))
                        justCli(path[0])
                        do_nothing()
                    else:
                        path = uniqueAtt(elementText, inside=inside, li=li)
                        print("xpath wala print : " + str(path[0]))
                        # justCli(uniqueAtt(elementText))
                        justCli(path[0])
                        do_nothing()
                else:
                    path = uniqueAtt(elementText)
                    print("xpath wala print : " + str(path[0]))
                    # justCli(uniqueAtt(elementText))
                    justCli(path[0])
                    do_nothing()


        except(SystemExit):
            print("It's Okay..!")
        except:
            print("Test Case Failed!!")
            print("Unexpected error:", sys.exc_info()[0])
            raise
        # except(TypeError):
        #     print('Could not find element')


#testSteps = ['Click on "Create Submission" button', f'Input "Inception Date" as "{d1}"', 'Click on "Insured" button' ]
#testSteps = ['Click on "Create Submission" button', 'Input "Inception Date" as "12/27/2020"']
#testSteps = ['Input "Username" as "ybdpu8r"', 'Input "Password" as "kuch bhi"']
import TestSteps
testSteps = TestSteps.testSteps1
# ['Input "User Email" as "cube.perform101.test@allianz.com"',
#              'Input "Password" as "rules"',
#              'Click on "Log in" button',
#              'Wait for "20" sec',
#              'Click on " Test101 Perform101" button',
#              'Wait for "2" sec',
#              'Hover on "Switch Application" button',
#              'Wait for "2" sec',
#              'Click on "Liability (Liability Underwriters)" button',
#              'Wait for "5" sec',
#              'Click on "Create Submission" button',
#              'Wait for "5" sec',
#              'Input "Inception Date" as "12/27/2020"',
#              'Wait for "1" sec',
#              'Click on "Insured" button',
#              'Wait for "2" sec',
#              'Input "Legal Name" as "xyz"',
#              'Wait for "1" sec',
#              'Click on "Search" inside "Legal Name" button',
#              'Wait for "10" sec'
#              ]

#testSteps = ['Wait for "1" sec','Input "sername" as "sanjog.maheshwari"', 'Input "assword" as "kuch bhi"', 'Click on "Log In" button']
# testSteps = ['Wait for "1" sec', 'Input "Username or email" as "75007162"',
#              'Input "Password" as "webuser123"', 'Click on "Log In" button',
#              'Wait for "2" sec',
#              'Click on "Schadenservice" button',
#              'Wait for "2" sec',
#              'Handel alert']
             #'Wait for "4" sec']
             # 'Input "TSN" as "COXX"',
             # 'Wait for "4" sec', 'Input " HSN " as "COXX"']

for smain in range(len(testSteps)):
    # if smain+1 < len(testSteps):
    #     testSteps[smain+1]
    #cli("//span[contains(text(),'Create Submission')]")
    #smain = 'Click on "Create Submission" button'
    #smain = 'Click on "Insured" button'
    #time.sleep(5)

    x = re.findall(r"['\"](.*?)['\"]", testSteps[smain])
    #x1 = None
    # if smain+1 < len(testSteps):
    #     x1 = re.findall(r"['\"](.*?)['\"]", testSteps[smain+1])
    j=1
    s1=None
    s2=None
    for y in x:
        if j == 1:
            s1 = y
        if j == 2:
            s2 = y
            print("Input Value S2 : "+s2)
        j=j+1

    if 'button' in testSteps[smain] and 'radio' not in testSteps[smain]:
        print('Inside Button')
        if s2 is None:
            if 'Hover' in testSteps[smain]:
                print("Hover hu mai")
                element_action(s1, inputvalue='Hover', li='button')
            else:
                element_action(s1, li='button')
        else:
            element_action(s1, inside=s2, li='button')

    elif 'Wait' in testSteps[smain]:
        time.sleep(int(s1))
    # elif 'Hover' in testSteps[smain]:
    #
    #     element_action(s1, inputvalue='Hover')
    elif 'Handel alert' in testSteps[smain]:
        print('alert me he')
        CancelAlert()
    else:
        if s2 is not None:
            print('Inside Input')
            element_action(s1,inputvalue=s2)
        else:
            print('Inside only element')
            element_action(s1)


time.sleep(5)
# suffixID = 'SF-USLL00071318'
# ent("//input[@id='txtUserID']","cube.perform101.test@allianz.com")
# ent("//input[@id='txtPassword']","rules")
# cli("//button[@id='sub']//span[@class='loginButtonText'][contains(text(),'Log in')]")
# justCli("//a[contains(text(),'Test101 Perform101')]")
# #cli("//a[contains(text(),'Test100 Perform100')]")
# hover("//span[contains(text(),'Switch Application')]")
# cli("//span[contains(text(),'Liability (Liability Underwriters)')]")


# xpath = '//'+i+'[@' + attname +'=\''+foundattrs[attname]+'\']'
# print(xpath)
# justCli(xpath)
#
# clear("//input[@id='OperatingEntityReceivedSubmission']")
#
# try:
#     justCli("//input[@id='OperatingEntityReceivedSubmission']")
# except ElementClickInterceptedException:
#     justCli("//input[@id='OperatingEntityReceivedSubmission']")
# ent("//input[@id='OperatingEntityReceivedSubmission']","AGCS Germany")
# ent("//input[@id='OperatingEntityReceivedSubmission']",Keys.TAB)
# try:
#     justCli("//input[@id='OperatingEntityReceivedSubmission']")
# except ElementClickInterceptedException:
#     justCli("//input[@id='OperatingEntityReceivedSubmission']")
# justEnt("//input[@id='OperatingEntityReceivedSubmission']",Keys.BACKSPACE)
# justEnt("//input[@id='OperatingEntityReceivedSubmission']","y")
# justEnt("//input[@id='OperatingEntityReceivedSubmission']",Keys.DOWN)
# justEnt("//input[@id='OperatingEntityReceivedSubmission']", Keys.DOWN)
# justEnt("//input[@id='OperatingEntityReceivedSubmission']",Keys.RETURN)
# ent("//input[@id='SubmissionReceivedDate']",d1)
# ent("//input[@id='InceptionDate']",d1)
# cli("//button[contains(@name,'PartyDetails_pyWorkPage.SubmissionPage.InsuredPartyPage_1')]")
# cli("//button[contains(@name,'NamesSearch_NamesSearchCriteriaPage_62')]")
#
# content = soupContent()
#
# LegalName=[]
# ListName=[]
# NameCode=[]
# Country=[]
# Street=[]
# City=[]
# PostCode=[]
# Usages=[]
# IRPID=[]
#
# for i in range(1,1):
#     try:
#
#         time.sleep(4)
#         soups = soupContent()
#         Data=soups.findAll('div', attrs={'class': 'oflowDivM'})
#         for i in range(0, 90, 9):
#             LegalName.append(Data[i].text)
#             ListName.append(Data[i+1].text)
#             NameCode.append(Data[i+2].text)
#             Country.append(Data[i+3].text)
#             Street.append(Data[i+4].text)
#             City.append(Data[i+5].text)
#             PostCode.append(Data[i+6].text)
#             Usages.append(Data[i+7].text)
#             IRPID.append(Data[i+8].text)
#
#         if i%10==1:
#             justCli("//a[contains(text(),'Next')]")
#         else:
#             justCli("//a[contains(text()," + str(i) + ")]")
#     except NoSuchElementException:
#         break
#
#
# flag=0
# if flag==0:
#     df = pd.DataFrame({'LegalName':LegalName,'ListName':ListName,'NameCode':NameCode,'Country':Country,
#     'Street':Street,'City':City,'PostCode':PostCode,'Usages':Usages,'IRPID':IRPID})
#     df.to_excel('BrokerData.xlsx', index=False, encoding='utf-8')
# else:
#     print("no write access")

quit()
print("Test Case Passed!!")