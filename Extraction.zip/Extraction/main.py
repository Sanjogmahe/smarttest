con = ['a', 'b', 'c']
gtr = []
print(con)
f = []
for i in gtr:
    print(i)
    con.append(i)

print(con)