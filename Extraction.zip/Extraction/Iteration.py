import subprocess
import sys

for scriptInstance in range(1):
    sys.stdout = open('result%s.txt' % scriptInstance, 'w')
    subprocess.check_call(['python', 'CubeDataExtraction.py'], \
                          stdout=sys.stdout, stderr=subprocess.STDOUT)