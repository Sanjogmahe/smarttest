import time

import pandas as pd
from selenium.common.exceptions import NoSuchElementException, ElementClickInterceptedException
from selenium.webdriver.common.keys import Keys
from datetime import date
from Extraction.Funtion import cli,ent,url,iframe,justCli,hover,clear,justEnt,soupContent,quit



today = date.today()
d1 = today.strftime("%m/%d/%Y")

url("https://samliew.com/nric-generator")
iban=[]
i=0
while i<2000:
    cli("//input[@id='gen']")
    soups = soupContent()
    Data=soups.findAll('img', attrs={'id': 'barcode'})
    for s in Data:
        Num = s.get("src")
        Nums= Num.split("text=")
        ibans=Nums[1]
    iban.append(ibans)
    i+=1
flag=0
if flag==0:
    df = pd.DataFrame({'IbanNo':iban})
    df.to_excel('IBAN.xlsx', index=False, encoding='utf-8')
else:
    print("no write access")

quit()
print("Test Case Passed!!")