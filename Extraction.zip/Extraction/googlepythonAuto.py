import time

import urllib3
from bs4 import BeautifulSoup
import pandas as pd
from selenium.common.exceptions import NoSuchElementException, ElementClickInterceptedException
from selenium.webdriver.common.keys import Keys
from datetime import date
from Extraction.Funtion import cli,ent,url,iframe,justCli,hover,clear,justEnt,soupContent,quit



today = date.today()
d1 = today.strftime("%m/%d/%Y")

url("https://www.google.com/")

content=soupContent()
elem=content(text=lambda text: text and text.startswith('Google angeboten auf: '))
for c in elem:
    print('**********')
    print(c.parent)
     for c in k:
         b = d
         print(d)
         while True:
             b = b.previous_element
             if not b.find(type='radio'):
                 print(b)
             else:
                 radioval = b
                 break
         fin = radioval.find_all(type='radio', value='renewable')
         for x in fin:
             print(x)


quit()