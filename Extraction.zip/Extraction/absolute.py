from lxml import etree

datum = """<html><body><td class="gridCell" data-importance="primary" style="height:36px;" tabindex="0" title=""><div class="oflowDivM"><span>Qaakhjup Gqhzqhovjqg</span></div></td>, <td class="gridCell" data-attribute-name="List Name" data-importance="secondary" headers="a2" style="height:34px;" title=""><div class="oflowDivM"><span>Qaakhjup Uiqloi</span></div></td>, <td class="gridCell" data-attribute-name="Name Code" data-importance="secondary" headers="a3" style="height:34px;" title=""><div class="oflowDivM"><span>ACCU0006</span></div></td>, <td class="gridCell" data-attribute-name="Country" data-importance="secondary" headers="a4" style="height:34px;" title=""><div class="oflowDivM"><span>United States</span></div></td>, <td class="gridCell" data-attribute-name="Street" data-importance="secondary" headers="a5" style="height:34px;" title=""><div class="oflowDivM"><span>6490 Iyyjap Gjhaip</span></div></td>, <td class="gridCell" data-attribute-name="City" data-importance="secondary" headers="a6" style="height:34px;" title=""><div class="oflowDivM"><span>Hmogbmjiip</span></div></td>, <td class="gridCell" data-attribute-name="Post Code/Zip Code" data-importance="secondary" headers="a7" style="height:34px;" title=""><div class="oflowDivM"><span>96643</span></div></td>, <td class="gridCell" data-attribute-name="UsagesDisplay" data-importance="secondary" headers="a8" style="height:34px;" title=""><div class="oflowDivM"><span>DEA</span></div></td>, <td class="gridCell" data-attribute-name="IRPIDDisplay" data-importance="secondary" headers="a9" style="height:34px;" title=""><div class="oflowDivM"><span>0030045871</span></div></td>, <td class="autocompleteAGleft gridCell" style="height:22px;" tabindex="0" title=""><div class="oflowDiv" style="height:22px;"><div class="divCont"><span class="wspan"></span><div class="cellIn"><span><span class="match-highlight">AGCS Germany</span></span></div></div></div></td></body></html>"""
# root = etree.fromstring(datum)
# tree = etree.ElementTree(root)
#
#
# flag_2= False
# for e in root.iter():
#     d = tree.getpath(e)
#     j = root.xpath("$text", text = "Qaakhjup Uiqloi")
#     print(j)
#     #x = root.xpath("$text", d)
#     find_text = etree.XPath("//text()")
#     text = find_text(root)
#     for a in text:
#         print('-----------------')
#         print(a)
#         if j == a:
#             print('Mil gaya')
#             flag_2 = True# 2 min tuko kuch check karna he mujhe# ho gaya shayad... karf doset code mai..okay


root = etree.fromstring(datum) # problem is here
print(root)
tree = etree.ElementTree(root)
print(tree)
print(root.xpath("//*[contains(text(), 'Qaakhjup Uiqloi')]"))
find_text = etree.XPath("//*[contains(text(), 'Qaakhjup Uiqloi')]")
for target in find_text(root):
    print(tree.getpath(target))