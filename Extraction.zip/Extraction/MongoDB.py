from pymongo import MongoClient

dbConnect = MongoClient('mongodb://localhost:27017/')

# print(dbConnect.list_database_names())
mydb = dbConnect["mydatabase"]
mycol = mydb["names"]
{"typeof " + mycol.find_one()}
# dbDic = {'xoro':
#              {'Paro':'Devdas'},
#          'xoro':
#              {'Garo':'Baro'}
#          }

# mycol.find_one({'xoro[1].Garo':'Baro'})
#x = mycol.delete_many({})

#print(x.deleted_count, " documents deleted.")

dblist = dbConnect.list_database_names()
print(dblist)

# for i in mycol.find({'.firstName':'Hans'}):
#     print(i)

# for i in mycol.find_one({},{'name': 'Goo Bhai', 'address': 'Goo chap'}):
#
#     print(i)\
# print(mycol.find_one({'name':{'$in':['Goo']}}))
if mycol.find_one({'name':{'$in':['Dhokla']}}) != None:
        print("Don't do anything bro")
else:
        mydict = {'name': 'Dhokla Bhai', 'address': 'Mirchi chap'}

        x = mycol.insert_one(mydict)

# for i in mycol.find():
#     print(i)